def is_staf(user):
    return user.is_staff